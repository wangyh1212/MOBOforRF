function v=hypervolume(P,N)


error(nargchk(2,3,nargin));
error(nargoutchk(0,1,nargout));


[n,d]=size(P);

if ~isscalar(N)
    C=N;
    N=size(C,1);
else
    C=rand(N,d);
end


fDominated=false(N,1);
lB=max(P);
fcheck=all(bsxfun(@lt, C, lB),2);

for k=1:n
    if any(fcheck)
        f=all(bsxfun(@lt, C(fcheck,:), P(k,:)),2);
        fDominated(fcheck)=f;
        fcheck(fcheck)=~f;
    end
end

v=sum(fDominated)/N;