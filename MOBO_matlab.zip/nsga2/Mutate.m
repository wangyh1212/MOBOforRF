



function y = Mutate(x, eta_m, p_m)

    nVar = numel(x); 
    y = x; 

    for i = 1:nVar
        if rand <= p_m 
            delta = 0;
            rand_val = rand(); 
            if rand_val <= 0.5
                delta = (2 * rand_val)^(1 / (eta_m + 1)) - 1;
            else
                delta = 1 - (2 * (1 - rand_val))^(1 / (eta_m + 1));
            end
            y(i) = x(i) + delta * (x(i) * (1 - x(i))); 
        end
    end

    y = min(max(y, 0), 1); 
end