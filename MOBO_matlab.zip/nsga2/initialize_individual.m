function individual = initialize_individual()
    
    individual.Position = [];              
    individual.Lashen = []; 
    individual.Para = []; 
    individual.Obj = [];                    
    individual.Cost = [];                  
    individual.Fre = [];                   
    
    individual.Rank = [];                   
    individual.DominationSet = [];          
    individual.DominatedCount = [];        
    
    individual.CrowdingDistance = [];       
    
    individual.Penalty = [];               
    individual.Variance = [];
    individual.f_Variance = [];
end