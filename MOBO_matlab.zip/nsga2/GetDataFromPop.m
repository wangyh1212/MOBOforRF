function [initial_data_pr, fre_pr, F_s_pr, fre_s_pr] = GetDataFromPop(pop)
   
    initial_data_pr = [];
    fre_pr = [];
    F_s_pr = [];
    fre_s_pr = [];

    
    for k = 1:length(pop)
        
        popk = [pop(k).Position pop(k).Fre pop(k).Obj pop(k).Lashen pop(k).Para];
        initial_data_pr = [initial_data_pr; popk];  

       
        fre_pr = [fre_pr; pop(k).Fre];  
        F_s_pr = [F_s_pr; pop(k).Variance];  
        fre_s_pr = [fre_s_pr; pop(k).f_Variance];  
    end
end