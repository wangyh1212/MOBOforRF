function pop = processPopulation(pop, empty_individual)

    pop_feasible = repmat(empty_individual, 0, 1); 
    pop_infeasible = repmat(empty_individual, 0, 1); 

   
    for i = 1:length(pop)
        diff = abs(pop(i).Fre - 499.65);
        
        if diff > 0.05
            pop_infeasible(end+1) = pop(i);
        else
            pop_feasible(end+1) = pop(i);
        end
    end

    
    [pop_infeasible, F_infeasible]=NonDominatedSorting(pop_infeasible); 
    pop_infeasible=CalcCrowdingDistance(pop_infeasible, F_infeasible);
    [pop_infeasible, F_infeasible] = SortPopulation(pop_infeasible);
    
    [pop_feasible, F_feasible]=NonDominatedSorting(pop_feasible); 
    pop_feasible=CalcCrowdingDistance(pop_feasible, F_feasible);
    [pop_feasible, F_feasible] = SortPopulation(pop_feasible);

   
    feasible_num = length(pop_feasible);

   
    if feasible_num >= 100
        pop_feasible = pop_feasible(1:100); 
        pop_infeasible = pop_infeasible(1:50); 
    else
        pop_temp = pop_infeasible(1:100 - feasible_num);
        pop_feasible = [pop_feasible pop_temp];
        pop_infeasible = pop_infeasible(100 - feasible_num + 1 : 100 - feasible_num + 50); 
    end


    pop = [pop_feasible pop_infeasible];
end