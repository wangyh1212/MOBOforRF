function pop=CalcCrowdingDistance(pop, F)

    nF=numel(F);
    for k=1:nF
        n=numel(F{k});
        if n == 0
            continue;
        end
        nObj = length(pop(F{k}(1)).Cost);
        Costs = zeros(nObj, n);
        for i = 1:n
            Costs(:, i) = pop(F{k}(i)).Cost;
        end
        d=zeros(n,nObj);
        

        for j = 1:nObj
            minCost = min(Costs(j, :)); 
            maxCost = max(Costs(j, :)); 
            range = maxCost - minCost;
            if range > 0
                Costs(j, :) = (Costs(j, :) - minCost) / range;
            else
                Costs(j, :) = 0; 
            end
        end
        
        
        for j=1:nObj
            [cj, so]=sort(Costs(j,:));  
            d(so(1),j)=inf;
            for i=2:n-1
                d(so(i),j)=abs(cj(i+1)-cj(i-1))/abs(cj(1)-cj(end));
            end
            
            d(so(end),j)=inf;
            
        end
        
        
        for i=1:n
            pop(F{k}(i)).CrowdingDistance=sum(d(i,:));  
        end
        
    end


end

