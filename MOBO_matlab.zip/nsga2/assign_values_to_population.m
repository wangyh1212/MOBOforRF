function pop = assign_values_to_population(pop, initial_data, max_value, F_s,fre_s)
    nInitialpop = length(pop); 
    for i = 1:nInitialpop
       
        pop(i).Position = initial_data(i, 1:13); 
        pop(i).Lashen = initial_data(i, 19:31); 
        pop(i).Para = initial_data(i, 32:44); 
        pop(i).Fre = initial_data(i, 14); 
        pop(i).Obj = initial_data(i, 15:18);

       
        deviation = abs(pop(i).Fre - 499.65);
        if deviation > 0.05
            penalty_factor = deviation;
        else
            penalty_factor = 0;
        end

        penalty_factor = penalty_factor * [-1, -1, 1, -1] / max_value;
        pop(i).Penalty = penalty_factor;


        popi_obj = pop(i).Obj;
        pop(i).Cost = popi_obj * diag([-1, -1, 1, -1]) + 0.5 * (pop(i).Penalty) .* (popi_obj * diag([-1, -1, 1, -1]));      %统一为最小化目标并加上惩罚项，这里惩罚系数设置为0.1
        pop(i).Variance = F_s(i,:);
        pop(i).f_Variance = fre_s(i,:);
    end
end