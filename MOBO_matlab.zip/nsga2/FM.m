function outputL = FM(inputL, gprModels)

    outputL = inputL;
    
    x = [inputL(:, 2:13)];
    x = [x, 499.65 * ones(size(x, 1), 1)];
    y = predict(gprModels.gprMdl_Req, x);  
    y = min(max(y, 0), 1);
    outputL(:, 1) = y;
end