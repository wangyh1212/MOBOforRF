function [F,fre,F_s,fre_s]=GetObjective(inputX, gprModels)

    x = inputX;
    y = [];
    s = [];
    
   %load('gprMdl_f_FM.mat','gprMdl_f_FM');
   [sim1,s1] = predict(gprModels.f_FM, x); 
   y = [y sim1];
   s = [s s1];
   %load('gprMdl_f_HOM.mat','gprMdl_f_HOM');
   [sim2,s2] = predict(gprModels.f_HOM, x);  
   y = [y sim2];
   s = [s s2];
   %load('gprMdl_RoverQ_FM.mat','gprMdl_RoverQ_FM');
   [sim3,s3] = predict(gprModels.RoverQ_FM, x);  
   y = [y sim3];
   s = [s s3];
   %load('gprMdl_RoverQ_HOM.mat','gprMdl_RoverQ_HOM');
   [sim4,s4] = predict(gprModels.RoverQ_HOM, x);  
   y = [y sim4];
   s = [s s4];
   %load('gprMdl_Ra_FM.mat','gprMdl_Ra_FM');
   [sim5,s5] = predict(gprModels.Ra_fm, x);  
   y = [y sim5];
   s = [s s5];
   
   F = [y(:, 2) y(:, 3) y(:, 4) y(:, 5)];
   fre = y(:, 1);
   F_s = [s(:, 2) s(:, 3) s(:, 4) s(:, 5)];
   fre_s = s(:, 1);

end
