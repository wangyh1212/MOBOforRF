function [X, Y, para] = LHSinitial(InitialNum)


    X = lhsdesign(InitialNum, 13);

    ranges = [
        100, 200;   
        0.01, 0.95; 
        0.05, 0.95; 
        0.05, 0.95; 
        1, 250; 
        0.15, 0.95; 
        0.15, 0.95; 
        0.05, 0.95; 
        0.05, 0.95; 
        0.05, 0.95; 
        0.05, 0.95; 
        0.05, 0.70; 
        0.05, 0.70; 
    ];
    for i = 1:13
        a = ranges(i, 1);
        b = ranges(i, 2);

        Y(:, i) = a + (b - a) .* X(:, i)  ;
    end


    results = table;
    Rt = 16;
    results.Req = Rt + Y(:, 1);
    results.nose = (results.Req - Rt) .* Y(:, 2);
    results.R3_right = (results.Req - Rt - results.nose) .* (1 - Y(:, 3));
    results.R3_left = (results.Req - Rt - results.nose) .* (1 - Y(:, 4));
    results.Leq = 2 * max(results.R3_right, results.R3_left) + Y(:, 5);
    results.cocave = results.Leq / 2 .* Y(:, 6);
    results.concave_L = results.Leq / 2 .* Y(:, 7);
    alpha_r = atan(Y(:, 3) .* (results.Req - Rt - results.nose) ./ results.cocave);
    alpha_l = atan(Y(:, 4) .* (results.Req - Rt - results.nose) ./ results.concave_L);
    results.r2_right = Y(:, 12) .* results.R3_right .* (sin(alpha_r) + cos(alpha_r)) ./ (1 + cos(alpha_r));
    results.r2_left = Y(:, 13) .* results.R3_left .* (sin(alpha_l) + cos(alpha_l)) ./ (1 + cos(alpha_l));
    results.r1_right = Y(:, 10) .* results.nose .* cos(alpha_r) ./ (1 - sin(alpha_r));
    results.r1_left = Y(:, 11) .* results.nose .* cos(alpha_l) ./ (1 - sin(alpha_l));
    results.r0_right = Y(:, 8) .* (1 - Y(:, 10)) .* results.nose;
    results.r0_left = Y(:, 9) .* (1 - Y(:, 11)) .* results.nose;
    para = table2array(results);
end