function [F1] = nsga2(objfun, numVars, numObj, pop_size, max_gen, gprModels)

   
    CostFunction=objfun;      
    nVar=numVars;             
    VarSize=[1 nVar];         
    VarMin=0;                 
    VarMax=1;                 
    nObj=numObj;              
    
   
    MaxIt=max_gen;                          
    nPop=pop_size;                         
    pCrossover=1;                         
    nCrossover=2*round(pCrossover*nPop/2);  
    pMutation=0.4;                          
    nMutation=round(pMutation*nPop);           
     mu=0.1;                              
     sigma=20;             


    empty_individual = initialize_individual();
                         

    rng('shuffle');
    [X, Y, para] = LHSinitial(1000)   ;          
    [F,fre,F_s,fre_s]=GetObjective(X, gprModels) ;   
    initial_data = [X fre F Y para];
    
    abs_diff = abs(fre - 499.65);
    max_value = max(abs_diff);
    
   
    nInitialpop = size(initial_data, 1);              
    pop=repmat(empty_individual,nInitialpop,1);     
    pop = assign_values_to_population(pop, initial_data, max_value,F_s,fre_s);
    
    pop = processPopulation(pop, empty_individual);

    
    
    for it=1:MaxIt
        [data_pr, fre_pr, F_s_pr, fre_s_pr] = GetDataFromPop(pop);
        pop_all = pop;
        
        popc=repmat(empty_individual,nCrossover/2,2);   
        for k=1:nCrossover/2
            i1=randi([1 nPop]);
            p1=pop_all(i1);
            i2=randi([1 nPop]);
            while i2 == i1
                i2 = randi([1 nPop]);
            end
            p2=pop_all(i2);
            [popc(k,1).Position, popc(k,2).Position]=Crossover(p1.Position,p2.Position);
             popc(k,1).Position = FM(popc(k,1).Position, gprModels);  
             popc(k,2).Position = FM(popc(k,2).Position, gprModels);  
        end
        popc=popc(:);
 
        
        popm=repmat(empty_individual,nMutation,1);
        for k=1:nMutation
            i=randi([1 nPop]);
            p=pop_all(i);
            popm(k).Position=Mutate(p.Position,mu,sigma);
             popm(k).Position = FM(popm(k).Position, gprModels); 
            
        end

        popcm=[
            popc
            popm];
        positions_matrix = [];
        for k=1:length(popcm)
            positions_matrix = [positions_matrix; popcm(k).Position];
        end      

        [F_cm,fre_cm,F_s_cm,fre_s_cm]=GetObjective(positions_matrix, gprModels) ;     %使用代理模型预测
        [Y_cm, para_cm] = Mapping(positions_matrix);
        data_cm = [positions_matrix fre_cm F_cm Y_cm para_cm];
        
        data = [data_pr; data_cm];
        fre = [fre_pr; fre_cm ];
        F_s = [F_s_pr;F_s_cm];
        fre_s = [fre_s_pr;fre_s_cm];
        
        abs_diff = abs(fre - 499.65);
        max_value = max(abs_diff);

       
        pop1 = repmat(empty_individual,nPop+nCrossover+nMutation,1); 
        pop1 = assign_values_to_population(pop1, data, max_value, F_s,fre_s);
        pop = pop1;
        

        targetFre = 499.65;
        tolerance = 0.05;
        freValues = [pop.Fre]; 
        indices = abs(freValues - targetFre) <= tolerance;
        filteredPop = pop(indices);
        
      
        [filteredPop, F]=NonDominatedSorting(filteredPop);             

        F1=filteredPop(F{1});             
        

        disp(['Iteration ' num2str(it) ': Number of F1 Members = ' num2str(numel(F1))]);
        
        pop = processPopulation(pop, empty_individual);
    

end
    
end