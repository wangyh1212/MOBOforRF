function cst_calculate(rowData, DataPath, ind1, ind2, columnNames, mws)
    
    for j = 1:width(rowData)
        columnName = columnNames{j}; 
        columnValue = rowData{1, columnName};
        invoke(mws, 'StoreParameter', columnName, columnValue);
    end
    invoke(mws, 'RebuildOnParametricChange', 'False', 'True');

    
    solver = invoke(mws, 'EigenmodeSolver');

    
    invoke(solver, 'Start');

    
    SelectTreeItem = invoke(mws, 'SelectTreeItem', 'Tables\0D Results\Frequency (Multiple Modes)');
    
    ASCIIExport = invoke(mws, 'ASCIIExport');
    
    invoke(ASCIIExport, 'Reset');
    
    invoke(ASCIIExport, 'SetVersion', '2010');
    
    output_txt_file = fullfile(DataPath, 'Frequency', sprintf('result_%d_%d.txt', ind1, ind2));
    invoke(ASCIIExport, 'FileName', output_txt_file);
    
    invoke(ASCIIExport, 'Execute');
    
    
    SelectTreeItem = invoke(mws, 'SelectTreeItem', 'Tables\0D Results\Q-Factor (Perturbation) (Multiple Modes)');
    
    ASCIIExport = invoke(mws, 'ASCIIExport');
    
    invoke(ASCIIExport, 'Reset');
    
    invoke(ASCIIExport, 'SetVersion', '2010');
    
    output_txt_file = fullfile(DataPath, 'Q-Factor', sprintf('result_%d_%d.txt', ind1, ind2));
    invoke(ASCIIExport, 'FileName', output_txt_file);
    
    invoke(ASCIIExport, 'Execute');
    
    
    SelectTreeItem = invoke(mws, 'SelectTreeItem', 'Tables\0D Results\R over Q beta=1 (Multiple Modes)');
    
    ASCIIExport = invoke(mws, 'ASCIIExport');
    
    invoke(ASCIIExport, 'Reset');
    
    invoke(ASCIIExport, 'SetVersion', '2010');

    output_txt_file = fullfile(DataPath, 'RoverQ', sprintf('result_%d_%d.txt', ind1, ind2));
    invoke(ASCIIExport, 'FileName', output_txt_file);

    invoke(ASCIIExport, 'Execute');

    SelectTreeItem = invoke(mws, 'SelectTreeItem', 'Tables\0D Results\Shunt Impedance (Pertubation) beta=1 (Multiple Modes)');

    ASCIIExport = invoke(mws, 'ASCIIExport');

    invoke(ASCIIExport, 'Reset');

    invoke(ASCIIExport, 'SetVersion', '2010');

    output_txt_file = fullfile(DataPath, 'ShuntImpedance', sprintf('result_%d_%d.txt', ind1, ind2));
    invoke(ASCIIExport, 'FileName', output_txt_file);

    invoke(ASCIIExport, 'Execute');
    
    invoke(mws,'DeleteResults'); 


end