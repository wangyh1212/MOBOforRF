function [hypervolumes] = clc_hypervolume(initial_data, r)
    F = initial_data;

    F(:, 3) =  F(:, 3) + max(-F(:, 3)) * 1.1;

    G = F * diag(1 ./ r);
    hypervolumes = hypervolume(G, 10000);
end