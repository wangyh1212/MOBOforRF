
function P = paretofront(F)
    F(:, 3) = -F(:, 3);
    [n, d] = size(F);
    P = true(1, n); 

    for i = 1:n
        for j = 1:n
            if all(F(j,:) >= F(i,:)) && any(F(j,:) > F(i,:))
                P(i) = false; 
                break;
            end
        end
    end

    P = find(P); 
end