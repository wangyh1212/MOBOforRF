function updated_vector = update_lhs(input_vector)
    input_vector(1) = input_vector(1) + (input_vector(14) - 499.65) / 255;
    updated_vector = input_vector(1:13);
    updated_vector = min(max(updated_vector, 0), 1); 
end