function T = readDataFromFile(filePath)
    varNames = {'Mode1', 'Mode2'};
    T = table('Size', [1 2], 'VariableTypes', {'double', 'double'}, 'VariableNames', varNames);
    fileID = fopen(filePath, 'r');
    if fileID == -1
        error('File cannot be opened: %s', filePath);
    end
    
    tag = '';
    index = 1;
    while ~feof(fileID)
        line = fgetl(fileID);
        if isempty(line) || all(ismember(line, '-'))
            continue;
        end
        key_parts = strsplit(line, ' /');
        key = strtrim(key_parts{1});
        if mod(index, 2) ==0
            numStart = strfind(key, ' '); 
            numStr = strtrim(key(numStart(1)+1:end)); 
            num = str2double(numStr); 
        end
        switch tag
            case 'Mode 1/real'
                T.('Mode1')(1) = num;
            case 'Mode 2/real'
                T.('Mode2')(1) = num;
        end

        tag = key;
        index = index+1;
    end

    fclose(fileID);
end