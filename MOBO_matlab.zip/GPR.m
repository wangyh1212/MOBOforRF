function gprModels = GPR(initial_data)

    data = initial_data;
    
    
    X = data(:, 1: 13);
    Y1 = initial_data(:, 14);%f
    Y2 = data(:, 15) - data(:, 14);%fHOM-f
    Y3 = data(:, 16);%R/Q
    Y4 = data(:, 17);%R/Qtomin
    Y5 = data(:, 18);%Ra
    

    gprMdl_f_FM = fitrgp(X, Y1, 'KernelFunction', 'ardsquaredexponential', 'OptimizeHyperparameters', 'none');
    %save(fullfile('nsga2', 'gprMdl_f_FM.mat'),'gprMdl_f_FM');
    gprMdl_f_HOM = fitrgp(X, Y2, 'KernelFunction', 'ardsquaredexponential', 'OptimizeHyperparameters', 'none');
    %save(fullfile('nsga2', 'gprMdl_f_HOM.mat'),'gprMdl_f_HOM');
    gprMdl_RoverQ_FM = fitrgp(X, Y3, 'KernelFunction', 'ardsquaredexponential', 'OptimizeHyperparameters', 'none');
    %save(fullfile('nsga2',  'gprMdl_RoverQ_FM.mat'),'gprMdl_RoverQ_FM');
    gprMdl_RoverQ_HOM = fitrgp(X, Y4, 'KernelFunction', 'ardsquaredexponential', 'OptimizeHyperparameters', 'none');
    %save(fullfile('nsga2', 'gprMdl_RoverQ_HOM.mat'),'gprMdl_RoverQ_HOM');
    gprMdl_Ra_FM = fitrgp(X, Y5, 'KernelFunction', 'ardsquaredexponential', 'OptimizeHyperparameters', 'none');
    %save(fullfile('nsga2', 'gprMdl_Ra_FM.mat'),'gprMdl_Ra_FM');
    

    gprModels.f_FM = gprMdl_f_FM;
    gprModels.f_HOM = gprMdl_f_HOM;
    gprModels.RoverQ_FM = gprMdl_RoverQ_FM;
    gprModels.RoverQ_HOM = gprMdl_RoverQ_HOM;
    gprModels.Ra_fm = gprMdl_Ra_FM;
    

    res_combined = data(:, 1: 14);
    data = [res_combined(:,2:end), res_combined(:,1)];
    
    XR = data(:, 1: 13);
    YR = data(:, 14);


    gprMdl_Req = fitrgp(XR, YR, 'KernelFunction', 'ardsquaredexponential', 'OptimizeHyperparameters', 'none');
    gprModels.gprMdl_Req = gprMdl_Req;
    
end