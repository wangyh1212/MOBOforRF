function temp_result = ReadCSTResult(filePath, ind1, ind2)

    folders = {'Frequency', 'Q-Factor', 'RoverQ', 'ShuntImpedance'};
    varNames = {'f_FM', 'f_HOM', 'RoverQ_FM', 'RoverQ_HOM', 'Ra_FM'};
    temp_result = table('Size', [1 5], 'VariableTypes', {'double', 'double', 'double', 'double', 'double'}, 'VariableNames', varNames);

    for j = 1:4
        folder = folders{j};
        fileName = sprintf('result_%d_%d.txt', ind1, ind2);
        FullfileName = fullfile(filePath, folder, fileName); 
        switch folder
            case 'Frequency'
                T = readDataFromFile(FullfileName);
                temp_result.f_FM(1) = T.Mode1;
                temp_result.f_HOM(1) = T.Mode2;
            case 'RoverQ'
                T = readDataFromFile(FullfileName);
                temp_result.RoverQ_FM(1) = T.Mode1;
                temp_result.RoverQ_HOM(1) = T.Mode2;
            case 'ShuntImpedance'
                T = readDataFromFile(FullfileName);
                temp_result.Ra_FM(1) = T.Mode1;
        end
    end
end