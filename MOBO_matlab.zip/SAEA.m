function [front,bestSolutions] = SAEA(init, gprModels)
    bestSolutions = [];
    tempBest = [];
    init(:, 2) = init(:, 2) - init(:, 1);
    init(:, 4) = -init(:, 4);
    init = init(:, 2:5);
    objfun = @(x) GetObjective(x); 
    numVars = 13;
    numObj = 4;
    max_gen = 400;
    pop_size = 150;
    [front] = nsga2(objfun, numVars, numObj, pop_size, max_gen, gprModels);
        
    for i = 1:10
        Obj = [];
        Variance = [];
        for j = 1:length(front)
            Obj = [Obj; front(j).Obj];
            Variance = [Variance; front(j).Variance];
        end
        F = Obj + 0.01*Variance;
        F(:, 3) =  -(Obj(:, 3) - 0.01*Variance(:, 3));
        allPoints = [init; F; tempBest];
        allPoints(:, 3) =  allPoints(:, 3) + max(-allPoints(:, 3)) * 1.1;
        r = max(allPoints);
        initialHypervolume = 0;
        maxImprovement = 0;
        bestPoint = [];
        bestIndex = 1;
        for j = 1:size(F, 1)
            updatedPoints = [init; tempBest; F(j, :)];
            newHypervolume = clc_hypervolume(updatedPoints, r);
            improvement = newHypervolume - initialHypervolume;
            if improvement > maxImprovement
                maxImprovement = improvement;
                bestPoint = F(j, :);
                bestIndex = j;
            end
        end
        bestSolutions = [bestSolutions, front(bestIndex)];
        tempBest = [tempBest; bestPoint];
        front(bestIndex) = [];
        
    end
