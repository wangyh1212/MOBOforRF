import numpy as np
import torch
from gpytorch.kernels import RBFKernel, ScaleKernel
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.mlls import ExactMarginalLogLikelihood
from botorch.models import SingleTaskGP
from botorch.fit import fit_gpytorch_mll
from pyswarms.single.global_best import GlobalBestPSO
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
import matplotlib
matplotlib.use('TkAgg')


torch.manual_seed(52)
np.random.seed(52)

dim = 2
num_objectives = 3


def objective_functions(x):
    if isinstance(x, torch.Tensor):
        if x.dim() == 1:
            x = x.unsqueeze(0)

        f1 = torch.norm(x - torch.ones_like(x), dim=-1)
        f2 = torch.norm(x + torch.ones_like(x), dim=-1)
        f3 = torch.abs(f1 - f2)

        return torch.stack([f1, f2, f3], dim=-1)
    else:
        if x.ndim == 1:
            x = x.reshape(1, -1)

        f1 = np.linalg.norm(x - np.ones_like(x), axis=-1)
        f2 = np.linalg.norm(x + np.ones_like(x), axis=-1)
        f3 = np.abs(f1 - f2)

        return np.column_stack([f1, f2, f3])

def generate_initial_samples(n_samples=5):
    x_init = np.random.uniform(-2, 2, size=(n_samples, dim))
    x_init_tensor = torch.tensor(x_init, dtype=torch.float64)
    y_init = objective_functions(x_init_tensor)
    return x_init_tensor, y_init

class UCBHVI:
    def __init__(self, models, ref_point, beta=0.01, pareto_Y=None):
        self.models = models
        self.ref_point = ref_point
        self.beta = beta
        self.pareto_Y = pareto_Y if pareto_Y is not None else torch.zeros((0, len(models)), dtype=torch.float64)
        self.threshold = 0.01

    def __call__(self, X):
        if X.dim() == 1:
            X = X.unsqueeze(0)
        means = []
        stds = []
        for model in self.models:
            posterior = model.posterior(X)
            mean = posterior.mean
            std = torch.sqrt(posterior.variance)
            means.append(mean)
            stds.append(std)
        means = torch.cat(means, dim=-1)
        stds = torch.cat(stds, dim=-1)

        ucb_values = means - self.beta * stds

        current_hv = self._compute_hypervolume(self.pareto_Y)
        hvi_values = torch.zeros(ucb_values.shape[0], dtype=torch.float64)
        for i in range(ucb_values.shape[0]):
            combined_Y = torch.cat([self.pareto_Y, ucb_values[i:i + 1]], dim=0)
            new_hv = self._compute_hypervolume(combined_Y)
            hvi_values[i] = new_hv - current_hv
        return -hvi_values

    def _compute_hypervolume(self, Y):
        if Y.shape[0] == 0:
            return torch.tensor(0.0, dtype=torch.float64)

        from botorch.utils.multi_objective.hypervolume import Hypervolume
        hv = Hypervolume(ref_point=self.ref_point)
        return hv.compute(-Y)

    def _get_non_dominated_mask(self, Y):
        mask = torch.ones(Y.shape[0], dtype=torch.bool)
        for i in range(Y.shape[0]):
            for j in range(Y.shape[0]):
                if i != j and torch.all(Y[j] <= Y[i]) and torch.any(Y[j] < Y[i]):
                    mask[i] = False
                    break
        return mask


def optimize_acqf_with_pso(acq_function, bounds, n_particles=50, iters=50):
    def objective_function(x):
        batch_x = torch.tensor(x, dtype=torch.float64)

        values = np.zeros(batch_x.shape[0])

        for i in range(batch_x.shape[0]):
            with torch.no_grad():
                xi = batch_x[i].unsqueeze(0)
                values[i] = acq_function(xi).item()

        return values

    options = {'c1': 0.5, 'c2': 0.3, 'w': 0.9}

    lb, ub = bounds
    optimizer = GlobalBestPSO(n_particles=n_particles, dimensions=dim, options=options,
                              bounds=(lb, ub))

    cost, pos = optimizer.optimize(objective_function, iters=iters)

    return torch.tensor([pos], dtype=torch.float64)


def create_gp_models(train_x, train_obj, lengthscale=1.0, variance=0.5):
    models = []

    for i in range(num_objectives):
        covar_module = ScaleKernel(
            RBFKernel(ard_num_dims=train_x.shape[-1]),
            outputscale=variance
        )

        covar_module.base_kernel.lengthscale = torch.tensor([lengthscale], dtype=torch.float64)

        model = SingleTaskGP(
            train_x,
            train_obj[:, i:i + 1],
            covar_module=covar_module,
            likelihood=GaussianLikelihood()
        )

        mll = ExactMarginalLogLikelihood(model.likelihood, model)
        fit_gpytorch_mll(mll)

        models.append(model)

    return models


def run_mobo(n_initial=5, n_iterations=20):
    train_x, train_obj = generate_initial_samples(n_initial)

    all_x = train_x.clone()
    all_obj = train_obj.clone()
    print(all_obj)
    ref_point = torch.tensor([-4.0, -4.0, -1.0], dtype=torch.float64)

    for iteration in range(n_iterations):
        print(f"迭代 {iteration + 1}/{n_iterations}")

        models = create_gp_models(train_x, train_obj, lengthscale=1.0, variance=0.5)

        non_dominated_mask = torch.ones(train_obj.shape[0], dtype=torch.bool)
        for i in range(train_obj.shape[0]):
            for j in range(train_obj.shape[0]):
                if i != j and torch.all(train_obj[j] <= train_obj[i]) and torch.any(train_obj[j] < train_obj[i]):
                    non_dominated_mask[i] = False
                    break
        pareto_Y = train_obj[non_dominated_mask]

        acq_func = UCBHVI(models=models, ref_point=ref_point, beta=0.01, pareto_Y=pareto_Y)

        bounds = ([-2.0, -2.0], [2.0, 2.0])
        next_x = optimize_acqf_with_pso(acq_func, bounds=bounds)

        with torch.no_grad():
            next_obj = objective_functions(next_x.squeeze(0))

            if next_obj.dim() == 1:
                next_obj = next_obj.unsqueeze(0)

        train_x = torch.cat([train_x, next_x])
        train_obj = torch.cat([train_obj, next_obj])

        all_x = torch.cat([all_x, next_x])
        all_obj = torch.cat([all_obj, next_obj])

    return all_x, all_obj


def compute_theoretical_pareto():
    t_values = np.linspace(0, 1, 100)

    pareto_x1 = -1 + 2 * t_values
    pareto_x2 = -1 + 2 * t_values
    pareto_x = np.column_stack([pareto_x1, pareto_x2])

    pareto_f1 = 2 * np.sqrt(2) * (1 - t_values)
    pareto_f2 = 2 * np.sqrt(2) * t_values
    pareto_f = np.column_stack([pareto_f1, pareto_f2])

    return pareto_x, pareto_f


all_x, all_obj = run_mobo(n_initial=5, n_iterations=20)

theoretical_pareto_x, theoretical_pareto_f = compute_theoretical_pareto()



def visualize_results(all_x, all_obj, theoretical_pareto_x, theoretical_pareto_f):
    non_dominated_mask = torch.ones(all_obj.shape[0], dtype=torch.bool)
    for i in range(all_obj.shape[0]):
        for j in range(all_obj.shape[0]):
            if i != j and torch.all(all_obj[j] <= all_obj[i]) and torch.any(all_obj[j] < all_obj[i]):
                non_dominated_mask[i] = False
                break

    pareto_front = all_obj[non_dominated_mask].numpy()
    pareto_x = all_x[non_dominated_mask].numpy()

    plt.figure(figsize=(5, 4))

    plt.plot(theoretical_pareto_f[:, 0], theoretical_pareto_f[:, 1], 'k--', linewidth=4,
             label='Theoretical Pareto front')

    plt.plot([0, 4],
             [0, 4],
             'r-', linewidth=1, label='y1 = y2')

    y_min = 0
    y_max = 4
    plt.fill_between([y_min, y_max], [y_min + 0.01, y_max + 0.01], [y_min - 0.01, y_max - 0.01], color='red', alpha=0.1,
                     label='|y1 - y2| < 0.01')
    plt.scatter(all_obj[5:, 0].numpy(), all_obj[5:, 1].numpy(), c='royalblue', s=160, label='Sampled points')
    plt.scatter(all_obj[:5, 0].numpy(), all_obj[:5, 1].numpy(), c='darkorange', s=320, marker='*', label='Initial points')


    plt.xlabel(r'$f_1(x) = \|x - 1\|$', fontsize=24)
    plt.ylabel(r'$f_2(x) = \|x + 1\|$', fontsize=24)

    plt.xlim([1.32, 1.54])
    plt.ylim([1.32, 1.54])
    plt.xticks(np.arange(1.4, 1.5, 0.05))
    plt.yticks(np.arange(1.4, 1.5, 0.05))

    plt.tick_params(axis='both', which='both', direction='in', labelsize=24)


    plt.tight_layout()
    plt.savefig(r'ewai0.01fang.png', dpi=300)
    plt.show()

visualize_results(all_x, all_obj, theoretical_pareto_x, theoretical_pareto_f)

print("最终获得的Pareto最优解（参数空间）：")
non_dominated_mask = torch.ones(all_obj.shape[0], dtype=torch.bool)
for i in range(all_obj.shape[0]):
    for j in range(all_obj.shape[0]):
        if i != j and torch.all(all_obj[j] <= all_obj[i]) and torch.any(all_obj[j] < all_obj[i]):
            non_dominated_mask[i] = False
            break

pareto_front = all_obj[non_dominated_mask].numpy()
pareto_x = all_x[non_dominated_mask].numpy()

for i in range(len(pareto_x)):
    print(f"x = [{pareto_x[i, 0]:.4f}, {pareto_x[i, 1]:.4f}], f = [{pareto_front[i, 0]:.4f}, {pareto_front[i, 1]:.4f}]")
