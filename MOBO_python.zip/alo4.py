import numpy as np
import torch
import gpytorch
from gpytorch.kernels import RBFKernel, ScaleKernel
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.means import ConstantMean
from gpytorch.mlls import ExactMarginalLogLikelihood
from botorch.models import SingleTaskGP
from botorch.models.model_list_gp_regression import ModelListGP
from botorch.fit import fit_gpytorch_mll
from botorch.utils import standardize
from botorch.utils.multi_objective.box_decompositions.non_dominated import FastNondominatedPartitioning
from botorch.acquisition.multi_objective import ExpectedHypervolumeImprovement
from botorch.utils.multi_objective.hypervolume import Hypervolume
from pyswarms.single.global_best import GlobalBestPSO
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
import matplotlib
matplotlib.use('TkAgg')
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.problem import Problem
from pymoo.optimize import minimize
from pymoo.factory import get_sampling, get_crossover, get_mutation
from pymoo.core.evaluator import Evaluator

torch.manual_seed(52)
np.random.seed(52)

dim = 2
num_objectives = 2
threshold = 0.1
REF_POINT = torch.tensor([-4.0, -4.0], dtype=torch.float64)


def objective_functions(x):
    if isinstance(x, torch.Tensor):
        if x.dim() == 1:
            x = x.unsqueeze(0)
        f1 = torch.norm(x - torch.ones_like(x), dim=-1)
        f2 = torch.norm(x + torch.ones_like(x), dim=-1)
        return torch.stack([f1, f2], dim=-1)
    else:
        if x.ndim == 1:
            x = x.reshape(1, -1)
        f1 = np.linalg.norm(x - np.ones_like(x), axis=-1)
        f2 = np.linalg.norm(x + np.ones_like(x), axis=-1)
        return np.column_stack([f1, f2])


def generate_initial_samples(n_samples=5):
    x_init = np.random.uniform(-2, 2, size=(n_samples, dim))
    x_init_tensor = torch.tensor(x_init, dtype=torch.float64)
    y_init = objective_functions(x_init_tensor)
    return x_init_tensor, y_init


def create_gp_models(train_x, train_obj, lengthscale=1.0, variance=0.5):
    models = []
    for i in range(num_objectives):
        covar_module = ScaleKernel(
            RBFKernel(ard_num_dims=train_x.shape[-1]),
            outputscale=variance
        )
        covar_module.base_kernel.lengthscale = torch.tensor([lengthscale], dtype=torch.float64)

        model = SingleTaskGP(
            train_x,
            train_obj[:, i:i + 1],
            covar_module=covar_module,
            likelihood=GaussianLikelihood()
        )

        mll = ExactMarginalLogLikelihood(model.likelihood, model)
        fit_gpytorch_mll(mll)
        models.append(model)
    return models


def create_model_list_gp(models):
    return ModelListGP(*models)


def find_pareto_solutions(Y):
    """
    找出帕累托前沿上的解

    参数:
    Y: 目标函数值 (n x num_objectives)

    返回:
    非支配解的索引
    """
    n = Y.shape[0]
    pareto_indices = []

    for i in range(n):
        dominated = False
        for j in range(n):
            if i != j:
                if isinstance(Y, torch.Tensor):
                    if torch.all(Y[j] <= Y[i]) and torch.any(Y[j] < Y[i]):
                        dominated = True
                        break
                else:
                    if np.all(Y[j] <= Y[i]) and np.any(Y[j] < Y[i]):
                        dominated = True
                        break
        if not dominated:
            pareto_indices.append(i)

    return pareto_indices


class UCBHVI:
    def __init__(self, models, ref_point, train_Y, beta=0.01):
        self.models = models
        self.ref_point = ref_point
        self.beta = beta

        pareto_indices = find_pareto_solutions(train_Y)
        self.pareto_Y = train_Y[pareto_indices]

    def __call__(self, X):
        if X.dim() == 1:
            X = X.unsqueeze(0)

        means = []
        stds = []
        for model in self.models:
            posterior = model.posterior(X)
            mean = posterior.mean
            std = torch.sqrt(posterior.variance)
            means.append(mean)
            stds.append(std)

        means = torch.cat(means, dim=-1)
        stds = torch.cat(stds, dim=-1)

        ucb_values = means - self.beta * stds

        current_hv = self._compute_hypervolume(self.pareto_Y)

        hvi_values = torch.zeros(ucb_values.shape[0], dtype=torch.float64)
        for i in range(ucb_values.shape[0]):
            combined_Y = torch.cat([self.pareto_Y, ucb_values[i:i + 1]], dim=0)


            new_hv = self._compute_hypervolume(combined_Y)

            hvi_values[i] = new_hv - current_hv

        return -hvi_values

    def _compute_hypervolume(self, Y):
        if Y.shape[0] == 0:
            return torch.tensor(0.0, dtype=torch.float64)

        hv = Hypervolume(ref_point=self.ref_point)
        return hv.compute(-Y)


def train_gp_model(train_x, train_y, lengthscale=1.0, variance=0.5):
    """
    使用训练数据训练GP模型

    参数:
    train_x: 训练数据的输入
    train_y: 训练数据的输出
    lengthscale: GP模型RBF核函数的长度尺度
    variance: GP模型的方差参数

    返回:
    model_list: 训练好的GP模型列表
    """
    models = create_gp_models(train_x, train_y, lengthscale, variance)

    model_list = create_model_list_gp(models)

    return model_list


def optimize_with_nsga2_penalty(model_list, pop_size=50, n_gen=50, penalty_factor=100.0):
    """
    在训练好的GP模型上应用带惩罚的NSGA-II进行优化
    使用惩罚方法处理约束 |y1-y2| < 0.1

    参数:
    model_list: 训练好的GP模型列表
    pop_size: NSGA-II种群大小
    n_gen: NSGA-II迭代代数
    penalty_factor: 惩罚因子，控制约束违反的惩罚程度

    返回:
    best_x: 最优解的输入
    best_y: 最优解的输出
    """

    class GP_MOO_Penalty_Problem(Problem):
        def __init__(self, gp_model, penalty_factor):
            super().__init__(n_var=dim,
                             n_obj=num_objectives,
                             n_constr=0,
                             xl=np.array([-2.0] * dim),
                             xu=np.array([2.0] * dim))
            self.gp_model = gp_model
            self.penalty_factor = penalty_factor

        def _evaluate(self, x, out, *args, **kwargs):
            x_torch = torch.tensor(x, dtype=torch.float64)

            with torch.no_grad(), gpytorch.settings.fast_pred_var():
                y_preds = []
                for i, model in enumerate(self.gp_model.models):
                    posterior = model.posterior(x_torch)
                    mean = posterior.mean.detach().numpy()
                    y_preds.append(mean)

                y_pred = np.column_stack(y_preds)

            self.raw_objectives = y_pred.copy()

            y1 = y_pred[:, 0]
            y2 = y_pred[:, 1]
            constraint_violation = np.maximum(0, np.abs(y1 - y2) - threshold)

            penalized_y_pred = y_pred.copy()
            penalized_y_pred[:, 0] += self.penalty_factor * constraint_violation
            penalized_y_pred[:, 1] += self.penalty_factor * constraint_violation

            out["F"] = penalized_y_pred

    problem = GP_MOO_Penalty_Problem(model_list, penalty_factor)

    algorithm = NSGA2(
        pop_size=pop_size,
        sampling=get_sampling("real_random"),
        crossover=get_crossover("real_sbx", prob=0.9, eta=15),
        mutation=get_mutation("real_pm", eta=20),
        eliminate_duplicates=True
    )

    results = minimize(
        problem,
        algorithm,
        ('n_gen', n_gen),
        seed=42,
        verbose=False
    )

    X = results.X

    x_torch = torch.tensor(X, dtype=torch.float64)
    with torch.no_grad(), gpytorch.settings.fast_pred_var():
        y_preds = []
        for i, model in enumerate(model_list.models):
            posterior = model.posterior(x_torch)
            mean = posterior.mean.detach().numpy()
            y_preds.append(mean)

        F_raw = np.column_stack(y_preds)

    y1 = F_raw[:, 0]
    y2 = F_raw[:, 1]
    constraint_satisfied = np.abs(y1 - y2) < threshold

    if np.any(constraint_satisfied):
        X_feasible = X[constraint_satisfied]
        F_feasible = F_raw[constraint_satisfied]

        pareto_indices = find_pareto_solutions(F_feasible)

        best_x = X_feasible[pareto_indices]
        best_y = F_feasible[pareto_indices]
    else:
        print("警告: 未找到满足约束的解，返回全部解")
        best_x = X
        best_y = F_raw

    return best_x, best_y


def select_next_point_with_ucbhvi(model_list, candidates_x, candidates_y, train_y, beta=0.01):
    """
    使用UCBHVI采集函数选择下一个评估点

    参数:
    model_list: 训练好的GP模型列表
    candidates_x: 候选点的x值
    candidates_y: 候选点的y值预测值
    train_y: 训练数据的y值
    beta: UCB的探索参数

    返回:
    next_x: 选择的下一个点
    """
    candidates_x_tensor = torch.tensor(candidates_x, dtype=torch.float64)
    train_y_tensor = torch.tensor(train_y, dtype=torch.float64)

    ref_point = REF_POINT

    ucbhvi = UCBHVI(
        models=model_list.models,
        ref_point=ref_point,
        train_Y=train_y_tensor,
        beta=beta
    )

    with torch.no_grad():
        acq_values = ucbhvi(candidates_x_tensor)

    best_idx = torch.argmin(acq_values)
    next_x = candidates_x_tensor[best_idx].numpy()

    return next_x


def iterative_optimization(n_initial=5, n_iterations=20, pop_size=50, n_gen=50):
    """
    迭代优化过程：
    1. 生成初始样本点并训练GP模型
    2. 使用NSGA-II在GP模型上寻找帕累托前沿
    3. 使用UCBHVI选择超体积改进最大的点进行真实评估
    4. 将新点加入训练集，重新训练GP模型
    5. 重复步骤2-4

    参数:
    n_initial: 初始样本点数量
    n_iterations: 迭代次数
    pop_size: NSGA-II种群大小
    n_gen: NSGA-II迭代代数

    返回:
    x_train: 最终的训练集输入
    y_train: 最终的训练集输出
    pareto_x: 最终帕累托前沿的输入
    pareto_y: 最终帕累托前沿的输出
    selected_x_history: 每次迭代选择的点
    selected_y_history: 每次迭代选择的点的函数值
    """
    x_train, y_train = generate_initial_samples(n_samples=n_initial)

    selected_x_history = []
    selected_y_history = []
    pareto_x_history = []
    pareto_y_history = []

    for iteration in range(n_iterations):
        print(f"\n迭代 {iteration + 1}/{n_iterations}")

        model_list = train_gp_model(x_train, y_train)

        pareto_x, pareto_y = optimize_with_nsga2_penalty(
            model_list,
            pop_size=pop_size,
            n_gen=n_gen
        )

        pareto_x_history.append(pareto_x)
        pareto_y_history.append(pareto_y)

        next_x = select_next_point_with_ucbhvi(
            model_list,
            pareto_x,
            pareto_y,
            y_train
        )

        next_x_tensor = torch.tensor(next_x, dtype=torch.float64).unsqueeze(0)
        next_y = objective_functions(next_x_tensor)

        constraint_value = abs(next_y[0, 0].item() - next_y[0, 1].item())
        constraint_satisfied = constraint_value < threshold

        print(f"选择点: {next_x}")
        print(f"函数值: {next_y[0].numpy()}")
        print(f"约束值 |y1-y2| = {constraint_value:.6f} {'✓' if constraint_satisfied else '✗'}")

        selected_x_history.append(next_x)
        selected_y_history.append(next_y[0].numpy())

        x_train = torch.cat([x_train, next_x_tensor], dim=0)
        y_train = torch.cat([y_train, next_y], dim=0)

        print(f"当前训练集大小: {x_train.shape[0]} 点")

    model_list = train_gp_model(x_train, y_train)
    pareto_x, pareto_y = optimize_with_nsga2_penalty(
        model_list,
        pop_size=pop_size,
        n_gen=n_gen
    )

    return x_train, y_train, pareto_x, pareto_y, selected_x_history, selected_y_history, pareto_x_history, pareto_y_history


def compute_theoretical_pareto():
    t_values = np.linspace(0, 1, 100)

    pareto_x1 = -1 + 2 * t_values
    pareto_x2 = -1 + 2 * t_values
    pareto_x = np.column_stack([pareto_x1, pareto_x2])

    pareto_f1 = 2 * np.sqrt(2) * (1 - t_values)
    pareto_f2 = 2 * np.sqrt(2) * t_values
    pareto_f = np.column_stack([pareto_f1, pareto_f2])

    return pareto_x, pareto_f


'''
# 可视化结果的函数
def visualize_results(x_train, y_train, pareto_x, pareto_y, selected_x_history, selected_y_history, theoretical_pareto_f):
    plt.figure(figsize=(10, 8))

    # 绘制初始训练点的目标函数值
    plt.scatter(y_train[:, 0].numpy(), y_train[:, 1].numpy(), c='blue', s=50, label='训练点')

    # 绘制选择的历史点
    if selected_x_history is not None and selected_y_history is not None:
        selected_y = np.array(selected_y_history)
        plt.scatter(selected_y[:, 0], selected_y[:, 1], c='green', s=70, marker='*', label='迭代选择的点', alpha = 0.1)

    # 绘制最终NSGA-II找到的最优解
    plt.scatter(pareto_y[:, 0], pareto_y[:, 1], c='red', s=80, label='最终帕累托前沿')

    # 绘制对角线 y1=y2
    min_val = min(np.min(y_train.numpy()), np.min(pareto_y))
    max_val = max(np.max(y_train.numpy()), np.max(pareto_y))
    diag = np.linspace(min_val, max_val, 100)
    plt.plot(diag, diag, 'k--', label='y1=y2')

    # 绘制约束区域
    plt.fill_between(diag, diag - 0.1, diag + 0.1, color='green', alpha=0.2, label='约束区域 |y1-y2|<0.1')

    # 绘制参考点
    plt.scatter([REF_POINT[0]], [REF_POINT[1]], c='black', s=100, marker='x', label='参考点')

    plt.xlabel('目标1 (y1)')
    plt.ylabel('目标2 (y2)')
    plt.title('多目标优化结果与约束')
    plt.legend()
    plt.grid(True)
    plt.show()

'''


def visualize_results(x_train, y_train, theoretical_pareto_x, theoretical_pareto_f, selected_x_history,
                      selected_y_history):
    '''
    non_dominated_mask = torch.ones(all_obj.shape[0], dtype=torch.bool)
    for i in range(all_obj.shape[0]):
        for j in range(all_obj.shape[0]):
            if i != j and torch.all(all_obj[j] <= all_obj[i]) and torch.any(all_obj[j] < all_obj[i]):
                non_dominated_mask[i] = False
                break

    pareto_front = all_obj[non_dominated_mask].numpy()
    pareto_x = all_x[non_dominated_mask].numpy()
    '''
    plt.figure(figsize=(5, 4))

    plt.plot(theoretical_pareto_f[:, 0], theoretical_pareto_f[:, 1], 'k--', linewidth=4,
             label='Theoretical Pareto front')

    plt.plot([0, 4],
             [0, 4],
             'r-', linewidth=1, label='y1 = y2')

    y_min = 0
    y_max = 4
    plt.fill_between([y_min, y_max], [y_min + threshold, y_max + threshold], [y_min - threshold, y_max - threshold],
                     color='red', alpha=0.1,
                     label='|y1 - y2| < 0.1')
    plt.scatter(y_train[5:, 0].numpy(), y_train[5:, 1].numpy(), c='royalblue', s=160, label='Sampled points')
    plt.scatter(y_train[:5, 0].numpy(), y_train[:5, 1].numpy(), c='darkorange', s=320, marker='*', label='Initial points')

    plt.xlabel(r'$f_1(x) = \|x - 1\|$', fontsize=24)
    plt.ylabel(r'$f_2(x) = \|x + 1\|$', fontsize=24)
    plt.xlim([1.25, 1.65])
    plt.ylim([1.25, 1.65])
    plt.xticks(np.arange(1.3, 1.6, 0.1))
    plt.yticks(np.arange(1.3, 1.6, 0.1))
    plt.tick_params(axis='both', which='both', direction='in', labelsize=24)


    plt.tight_layout()
    plt.savefig(r'放大tAS0.1.png', dpi=300)
    plt.show()


def main():
    n_initial = 5
    n_iterations = 20
    pop_size = 50
    n_gen = 50

    x_train, y_train, pareto_x, pareto_y, selected_x_history, selected_y_history, pareto_x_history, pareto_y_history = iterative_optimization(
        n_initial=n_initial,
        n_iterations=n_iterations,
        pop_size=pop_size,
        n_gen=n_gen
    )

    theoretical_pareto_x, theoretical_pareto_f = compute_theoretical_pareto()
    visualize_results(x_train, y_train, theoretical_pareto_x, theoretical_pareto_f, selected_x_history,
                      selected_y_history)

    print("\n最终帕累托前沿:")
    for i in range(min(5, len(pareto_x))):
        print(f"X = {pareto_x[i]}, Y = {pareto_y[i]}")

    print("\n约束满足情况:")
    for i in range(len(pareto_y)):
        constraint_value = abs(pareto_y[i, 0] - pareto_y[i, 1])
        print(f"解 {i + 1} 的约束值 |y1-y2| = {constraint_value:.6f} {'✓' if constraint_value < 0.1 else '✗'}")


if __name__ == "__main__":
    main()